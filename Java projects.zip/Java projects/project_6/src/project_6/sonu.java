package project_6;

public class sonu {
	
	public sonu() {
	}
	 public sonu(String name) {
	}
}
