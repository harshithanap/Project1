package project_7;

public class X{
	   public void methodX()
	   {
	     System.out.println("class X method");
	   }
	}
	